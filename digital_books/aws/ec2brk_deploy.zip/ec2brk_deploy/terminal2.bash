cd kafka_2.13-3.2.0/bin
./kafka-server-start.sh ./../config/server.properties