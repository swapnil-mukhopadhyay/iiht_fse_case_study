export KAFKA_HOST=localhost
export BOOK_HOST=localhost
java -jar reader-0.0.1.jar