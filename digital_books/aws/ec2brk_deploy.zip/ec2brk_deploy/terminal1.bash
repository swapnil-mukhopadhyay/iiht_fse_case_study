sudo yum install java-1.8.0-openjdk
wget https://github.com/swapnil-mukhopadhyay/iiht_fse_case_study/raw/main/digital_books/aws/java/executable_jars/book-0.0.1.jar
wget https://github.com/swapnil-mukhopadhyay/iiht_fse_case_study/raw/main/digital_books/aws/java/executable_jars/reader-0.0.1.jar
wget https://archive.apache.org/dist/kafka/3.2.0/kafka_2.13-3.2.0.tgz
tar zxvf kafka_2.13-3.2.0.tgz
sudo su
rm -rf kafka_2.13-3.2.0.tgz
cd kafka_2.13-3.2.0/bin
./zookeeper-server-start.sh ./../config/zookeeper.properties